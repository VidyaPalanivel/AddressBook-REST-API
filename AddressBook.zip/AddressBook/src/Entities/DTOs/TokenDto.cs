namespace AddressBook.Entities.DTOs{
public class TokenDto
    {
        public string Token { get; set; }

        public string Type { get; set; }
       
    }
}