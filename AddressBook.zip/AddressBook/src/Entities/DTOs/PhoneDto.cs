using System.ComponentModel.DataAnnotations;

namespace AddressBook.Entities.DTOs{
    public class PhoneDto{
        
        public string PhoneNumber { get; set;}

        public string Type {get; set;}
    }
}